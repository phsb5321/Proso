# Firefox Extension Testing Strategy

Research document for Proso testing best practices.

**Last Updated:** 2026-01-09  
**Status:** Research Complete

## Table of Contents

1. [Playwright Firefox Testing](#1-playwright-firefox-testing)
2. [E2E Test Patterns for Extensions](#2-e2e-test-patterns-for-extensions)
3. [Visual Regression Testing](#3-visual-regression-testing)
4. [Flakiness Control](#4-flakiness-control)
5. [Firefox-Specific Challenges](#5-firefox-specific-challenges)
6. [CI/CD Integration](#6-cicd-integration)
7. [Proso Recommendations](#7-proso-recommendations)

---

## 1. Playwright Firefox Testing

### 1.1 Setting Up Playwright with Firefox

Playwright supports Firefox out of the box, but uses a **patched version** of Firefox (not the branded release).

```bash
# Install Playwright with Firefox
npx playwright install firefox
npx playwright install-deps firefox
```

**Key Limitation:** Playwright's Firefox differs from standard Firefox—it includes patches for automation. Visual and functional behavior may differ slightly from production Firefox.

```javascript
// playwright.config.js - Firefox project setup
import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  projects: [
    {
      name: 'firefox',
      use: {
        ...devices['Desktop Firefox'],
        launchOptions: {
          firefoxUserPrefs: {
            'extensions.autoDisableScopes': 0,
            'devtools.debugger.remote-enabled': true,
          },
        },
      },
    },
  ],
});
```

### 1.2 Loading Extensions in Firefox via Playwright

**Critical Limitation:** Playwright does **NOT** support loading extensions in Firefox the way it does for Chromium.

| Feature | Chromium | Firefox |
|---------|----------|---------|
| `--load-extension` flag | ✅ Yes | ❌ No |
| `launchPersistentContext` with extensions | ✅ Yes | ❌ No |
| Extension service worker access | ✅ Yes | ❌ No |
| `chrome-extension://` URLs | ✅ Yes | ❌ No (uses `moz-extension://`) |

From [Playwright docs](https://playwright.dev/docs/chrome-extensions):
> Extensions only work in Chromium when launched with a persistent context.

### 1.3 Alternatives for Firefox Extension Testing

#### Option A: web-ext (Recommended for Firefox)

Mozilla's official tool for extension development and testing:

```bash
# Install web-ext
npm install --global web-ext

# Run extension in Firefox
web-ext run --source-dir ./extension --firefox-binary $(which firefox)

# Run with specific profile
web-ext run --firefox-profile=./test-profile --keep-profile-changes
```

**web-ext + Playwright hybrid approach:**
1. Use `web-ext run` to start Firefox with extension loaded
2. Connect Playwright to the running browser using CDP or remote debugging
3. Run E2E tests against the browser with extension active

#### Option B: Selenium WebDriver with GeckoDriver

```javascript
const { Builder, Browser } = require('selenium-webdriver');
const firefox = require('selenium-webdriver/firefox');

const options = new firefox.Options();
options.addExtensions('./extension.xpi');
options.setPreference('xpinstall.signatures.required', false);

const driver = await new Builder()
  .forBrowser(Browser.FIREFOX)
  .setFirefoxOptions(options)
  .build();
```

#### Option C: Firefox Marionette Protocol

Direct browser automation via Marionette (Firefox's native automation protocol):

```python
# Python example
from marionette_driver.marionette import Marionette

client = Marionette(host='localhost', port=2828)
client.start_session()
client.install_addon('/path/to/extension.xpi', temp=True)
```

### 1.4 Proso Current Approach (Recommended)

The retained harnesses, in the order they gate the reading journey:

| Harness | Browser | What it proves |
|---------|---------|----------------|
| chrome-mv3 diagnostics (`scripts/chrome-mv3-diagnostics.mjs`) | Chromium + Firefox (raw geckodriver) | The MV3 worker audio shim (C1), the popup start journey to `playing` with a TTS request observed (C2), the message roundtrip (C3), the cold-worker race (C4), the offscreen document (C5); the Firefox leg loads the FULL extension via `installAddon` and drives the shipped popup |
| `make smoke-reading` / `make user-gate` | Firefox (geckodriver + public controls) | The reading journey against the fixture; the user gate drives public browser controls (see `.agents/skills/proso-user-gate`) |
| Visual regression (`packages/extension/tests/visual`, `packages/extension/playwright.config.js`) | Firefox | Serves the BUILT page over HTTP (webServer) so baselines render the real product CSS |
| Reader-journey oracle (`packages/extension/tests/integration/reader-journey.test.ts`) | jsdom (in-process) | Extraction → synthesis → audio → cache → highlight → controls, deterministic |

Playwright is Docker-only for E2E (see the delivery harness); the retained geckodriver
smoke covers the Firefox loaded-extension path without it.

---

## 2. E2E Test Patterns for Extensions

### 2.1 Testing Content Script Injection

**Pattern: Wait for injection marker**

```typescript
// tests/e2e/extension/content-injection.spec.ts
import { test, expect } from './fixtures/extension.fixture';

test('content script injects on page load', async ({ extensionPage }) => {
  await extensionPage.goto('https://example.com');
  
  // Wait for content script marker
  const injected = await extensionPage.waitForSelector(
    '[data-proso-injected]',
    { timeout: 5000, state: 'attached' }
  );
  
  expect(injected).toBeTruthy();
});
```

**Pattern: Verify DOM modifications**

```typescript
test('content script adds footer element', async ({ extensionPage }) => {
  await extensionPage.goto('https://example.com/article');
  
  // Content script should add footer
  await expect(extensionPage.locator('.proso-footer')).toBeVisible();
  
  // Footer should have play button
  await expect(extensionPage.locator('.proso-play-btn')).toBeEnabled();
});
```

### 2.2 Testing Background Script Functionality

**Pattern: Use service worker URL to verify extension loaded**

```typescript
// From Proso extension.fixture.ts
extensionId: async ({ context }, use) => {
  let serviceWorker = context.serviceWorkers()[0];
  
  if (!serviceWorker) {
    serviceWorker = await context.waitForEvent('serviceworker', {
      timeout: 30000,
    });
  }
  
  // Extract ID from URL: chrome-extension://<id>/background.js
  const extensionId = serviceWorker.url().split('/')[2];
  await use(extensionId);
},
```

**Pattern: Test message passing**

```typescript
test('background script responds to messages', async ({ extensionPage, extensionId }) => {
  // Navigate to page with content script
  await extensionPage.goto('https://example.com');
  
  // Trigger action that sends message to background
  await extensionPage.click('.proso-play-btn');
  
  // Verify response (e.g., audio state change)
  await expect(extensionPage.locator('[data-playing="true"]')).toBeVisible();
});
```

### 2.3 Testing Popup/Options Pages

**Pattern: Direct navigation to extension pages**

```typescript
test('popup displays correctly', async ({ context, extensionId }) => {
  const popupPage = await context.newPage();
  await popupPage.goto(`chrome-extension://${extensionId}/popup.html`);
  
  // Verify popup UI elements
  await expect(popupPage.locator('.popup-container')).toBeVisible();
  await expect(popupPage.locator('.settings-btn')).toBeEnabled();
});

test('settings page saves preferences', async ({ context, extensionId }) => {
  const settingsPage = await context.newPage();
  await settingsPage.goto(`chrome-extension://${extensionId}/settings.html`);
  
  // Change a setting
  await settingsPage.selectOption('#voice-select', 'en-US-female');
  await settingsPage.click('#save-btn');
  
  // Verify persistence
  await settingsPage.reload();
  await expect(settingsPage.locator('#voice-select')).toHaveValue('en-US-female');
});
```

### 2.4 Article Extraction (no PDF viewer)

The product has no PDF viewer: the `pdf` references in source are feature labels of the
page-reader work (`045-pdf-removal-page-reader` comments, e.g.
`packages/extension/src/utils/config/schema.ts:37`), not a PDF.js surface. Article
extraction and the reading journey are covered deterministically by the in-process oracle
`packages/extension/tests/integration/reader-journey.test.ts` (extraction → synthesis →
audio → cache → highlight → controls) and, in-browser, by the retained geckodriver
diagnostic (`scripts/chrome-mv3-diagnostics.mjs`).

---

## 3. Visual Regression Testing

### 3.1 Playwright Visual Comparison

```typescript
import { test, expect } from '@playwright/test';

test('hover state styling', async ({ page }) => {
  await page.emulateMedia({ colorScheme: 'light' });
  await setupTestPage(page);
  
  await page.hover('#paragraph-1');
  
  await expect(page).toHaveScreenshot('hover-state-light.png', {
    maxDiffPixelRatio: 0.02, // 2% tolerance
  });
});
```

### 3.2 Snapshot Configuration

```javascript
// playwright.config.js
export default defineConfig({
  expect: {
    toHaveScreenshot: {
      maxDiffPixelRatio: 0.02,
      threshold: 0.2, // Per-pixel threshold
    },
    toMatchSnapshot: {
      maxDiffPixelRatio: 0.02,
    },
  },
  
  // Consistent viewport for snapshots
  use: {
    viewport: { width: 800, height: 600 },
  },
});
```

### 3.3 Cross-Platform Visual Consistency

**Problem:** Screenshots differ between OS/browser combinations due to:
- Font rendering differences
- Anti-aliasing variations
- System color profiles
- Subpixel rendering

**Solutions:**

1. **Use stylePath to hide volatile elements:**

```css
/* screenshot.css - Applied during screenshots */
.dynamic-timestamp,
.animation-element,
iframe {
  visibility: hidden !important;
}

/* Force consistent font rendering */
* {
  -webkit-font-smoothing: antialiased !important;
  -moz-osx-font-smoothing: grayscale !important;
}
```

```typescript
await expect(page).toHaveScreenshot('test.png', {
  stylePath: './screenshot.css',
});
```

2. **Disable animations:**

```typescript
// Proso pattern from tests/helpers/disable-animations.js
export async function disableAnimations(page) {
  await page.addStyleTag({
    content: `
      *, *::before, *::after {
        animation-duration: 0s !important;
        animation-delay: 0s !important;
        transition-duration: 0s !important;
        transition-delay: 0s !important;
      }
    `,
  });
}
```

3. **Generate snapshots in consistent environment:**
   - Use Docker container for CI snapshots
   - Same container version for local updates
   - Document platform in snapshot filenames

### 3.4 Handling Dynamic Content

**Pattern: Mask dynamic regions**

```typescript
await expect(page).toHaveScreenshot('page.png', {
  mask: [
    page.locator('.timestamp'),
    page.locator('.user-avatar'),
    page.locator('.random-ad'),
  ],
});
```

**Pattern: Wait for layout stability**

```typescript
// Proso pattern
export async function waitForLayoutStable(page, selector, stableMs = 50) {
  const element = page.locator(selector);
  let lastBox = null;
  let stableCount = 0;
  
  while (stableCount < 3) {
    const box = await element.boundingBox();
    if (box && lastBox && 
        box.x === lastBox.x && 
        box.y === lastBox.y && 
        box.width === lastBox.width && 
        box.height === lastBox.height) {
      stableCount++;
    } else {
      stableCount = 0;
    }
    lastBox = box;
    await page.waitForTimeout(stableMs);
  }
}
```

---

## 4. Flakiness Control

### 4.1 Extension Loading Wait Strategies

**Problem:** Extension may not be loaded when test starts.

**Solution: Wait for service worker**

```typescript
// From Proso fixture
const SERVICE_WORKER_TIMEOUT = 30000;

if (!serviceWorker) {
  serviceWorker = await context.waitForEvent('serviceworker', {
    timeout: SERVICE_WORKER_TIMEOUT,
  });
}
```

**Solution: Verify extension ID before tests**

```typescript
test.beforeEach(async ({ extensionId }) => {
  if (!extensionId) {
    throw new Error('Extension failed to load');
  }
});
```

### 4.2 Async Message Passing

**Problem:** Messages between content script and background are async.

```typescript
// Bad: No wait
await page.click('.play-btn');
expect(await page.locator('.playing').isVisible()).toBe(true); // May fail!

// Good: Explicit wait
await page.click('.play-btn');
await expect(page.locator('.playing')).toBeVisible({ timeout: 5000 });
```

**Pattern: Wait for state change indicators**

```typescript
// Wait for specific attribute change
await page.click('.play-btn');
await page.waitForFunction(() => {
  const footer = document.querySelector('.proso-footer');
  return footer?.getAttribute('data-state') === 'playing';
}, { timeout: 5000 });
```

### 4.3 Article Extraction Wait Conditions

The product has no PDF viewer (see 2.4); the wait that matters for reading is the
content script's extraction readiness. The reader-journey oracle waits on observable
state, not arbitrary sleeps — see the `waitFor`/assertion pattern in
`packages/extension/tests/integration/reader-journey.test.ts` and the retained
geckodriver journey (`scripts/chrome-mv3-diagnostics.mjs` C2).

### 4.4 Audio Playback Testing

**Challenge:** Audio playback does not happen in a page's DOM. In Firefox MV2 the audio
element lives in the background event page (`playback-service.ts` `attachAndPlay`, which
creates `new Audio()`); in Chrome MV3 the worker-safe shim routes playback to the offscreen
document (`packages/extension/src/adapters/audio/offscreen-audio-element.adapter.ts`). No
`AudioContext` and no `window.speechSynthesis` are involved — browser
`speechSynthesis` was deliberately removed from the product (`9797dc6`, AGENTS.md
Firefox-First guideline 4), so no test should model it.

**The real route to test (server-managed playback):**

```
PlaybackService → ServerTtsAudioAdapter
  → ProsoApiAdapter.synthesize   (packages/extension/src/adapters/api/proso-api.adapter.ts:142-148)
  → POST /api/v1/tts/synthesize  ({text, provider, …}) → audio blob
```

**Deterministic strategies:**

1. **Stub `fetch` at the adapter boundary** — the reader-journey oracle does exactly this:
   `packages/extension/tests/integration/reader-journey.test.ts` installs a mocked `fetch`
   and asserts the request body (`{text, provider}`, no license key) and that playback
   reaches `playing`. This is the primary, deterministic pattern.
2. **Serve the reading fixture** (`scripts/lib/reading-fixture-server.mjs`) and drive the
   built extension with the retained geckodriver harness (`scripts/chrome-mv3-diagnostics.mjs`
   C2): the popup's Play click must leave `Loading...` via a real state, reach `playing`,
   and produce a TTS request observed by the fixture stub.
3. **Reader-operated host route** (no server): `LocalHostAudioAdapter`
   (`packages/extension/src/adapters/audio/local-host-audio.adapter.ts`) POSTs
   `{input, voice, speed}` to the reader-entered origin; the env-gated live receipt
   (`packages/extension/tests/integration/local-host-live.test.ts`) proves account-free
   audio against a real host.

**Never mock `speechSynthesis`** — the API does not exist in the product and modeling it
teaches the wrong surface.

### 4.5 General Flakiness Reduction

```javascript
// playwright.config.js
export default defineConfig({
  // Retries for flaky tests
  retries: process.env.CI ? 2 : 1,
  
  // Single worker for stability
  workers: process.env.CI ? 1 : undefined,
  
  // Global timeout
  timeout: 60000,
  
  // Capture artifacts on failure
  use: {
    trace: 'on-first-retry',
    video: 'retain-on-failure',
    screenshot: 'only-on-failure',
  },
});
```

---

## 5. Firefox-Specific Challenges

### 5.1 Extension Signing Requirements

Firefox requires extensions to be signed for permanent installation.

**Testing workarounds:**

1. **Temporary installation (development):**
   - Use `about:debugging` → "Load Temporary Add-on"
   - Extension unloads on browser restart
   
2. **Disable signature check (Nightly/Developer Edition):**
   ```javascript
   firefoxUserPrefs: {
     'xpinstall.signatures.required': false,
   }
   ```

3. **Use web-ext for testing:**
   ```bash
   web-ext run --source-dir ./extension
   ```

### 5.2 Profile Setup for Test Isolation

```bash
# Create test profile
firefox -CreateProfile "playwright-test"

# Find profile path
firefox -ProfileManager
```

**Playwright with custom profile:**

```javascript
use: {
  launchOptions: {
    args: ['-profile', '/path/to/test-profile'],
    firefoxUserPrefs: {
      // Disable first-run pages
      'browser.startup.homepage_override.mstone': 'ignore',
      'datareporting.policy.dataSubmissionEnabled': false,
      // Allow unsigned extensions
      'xpinstall.signatures.required': false,
      // Enable extension debugging
      'devtools.debugger.remote-enabled': true,
    },
  },
}
```

### 5.3 about:addons Page Access

Firefox blocks extension access to privileged pages like `about:addons`.

**Testing limitation:** Cannot programmatically verify extension appears in Add-ons Manager.

**Workaround:** Test extension functionality on regular web pages instead.

### 5.4 Article Pages (no PDF.js)

Proso reads web articles, not PDFs — there is no PDF.js surface to test (see 2.4).
Firefox's built-in PDF viewer is irrelevant to the extension's reading route; the
article path is covered by the reader-journey oracle and the geckodriver diagnostic
(`scripts/chrome-mv3-diagnostics.mjs`).

### 5.5 Content Security Policy Differences

Firefox enforces stricter CSP in some contexts.

**manifest.json CSP for MV3:**
```json
{
  "content_security_policy": {
    "extension_pages": "script-src 'self'; object-src 'self'"
  }
}
```

---

## 6. CI/CD Integration

### 6.1 GitHub Actions for Firefox Extension Tests

```yaml
# .github/workflows/test.yml
name: Firefox Extension Tests

on:
  push:
    branches: [main]
  pull_request:
    branches: [main]

jobs:
  visual-tests:
    name: Visual Tests (Firefox)
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      
      - name: Setup pnpm
        uses: pnpm/action-setup@v4
      
      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: '20'
          cache: 'pnpm'
      
      - name: Install dependencies
        run: pnpm install
      
      - name: Install Playwright Firefox
        run: npx playwright install --with-deps firefox
      
      - name: Build Firefox extension
        run: pnpm run build:firefox
      
      - name: Run visual tests
        run: pnpm run test:visual
      
      - name: Upload report on failure
        uses: actions/upload-artifact@v4
        if: failure()
        with:
          name: playwright-report
          path: playwright-report/
          retention-days: 7

  extension-e2e:
    name: Extension E2E (Chromium)
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      
      - name: Setup pnpm
        uses: pnpm/action-setup@v4
      
      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: '20'
          cache: 'pnpm'
      
      - name: Install dependencies
        run: pnpm install
      
      - name: Install Playwright Chromium
        run: npx playwright install --with-deps chromium
      
      - name: Build Chrome extension
        run: pnpm run build:chrome
      
      # Extension tests require headed mode
      - name: Run Extension E2E tests
        run: xvfb-run --auto-servernum -- pnpm run test:e2e:ext
        timeout-minutes: 10
      
      - name: Upload artifacts on failure
        uses: actions/upload-artifact@v4
        if: failure()
        with:
          name: extension-e2e-results
          path: |
            playwright-report/
            test-results/
          retention-days: 7
```

### 6.2 Docker Configuration

```yaml
# docker-compose.playwright.yml
version: '3.8'
services:
  e2e-tests:
    image: mcr.microsoft.com/playwright:v1.52.0-noble
    working_dir: /app
    volumes:
      - .:/app
      - ./test-results:/app/test-results
      - ./playwright-report:/app/playwright-report
    environment:
      - CI=true
    command: >
      sh -c "npm ci && 
             npm run build:chrome && 
             npx playwright test --project=chromium-extension"
    # Required for Chromium sandbox
    security_opt:
      - seccomp:unconfined
    # Recommended for Chromium
    ipc: host
```

**Recommended Docker flags:**
- `--init` - Proper PID 1 handling
- `--ipc=host` - Prevent Chromium memory issues
- `--cap-add=SYS_ADMIN` - For sandbox in development

### 6.3 NixOS-Specific Setup

Proso has NixOS support documented in `docs/e2e-nixos.md`.

**Key points:**

1. **Use system browsers:**
   ```bash
   export FIREFOX_PATH=$(which firefox)
   export CHROMIUM_PATH=$(which chromium)
   ```

2. **shell.nix for reproducible environment:**
   ```nix
   { pkgs ? import <nixpkgs> {} }:
   pkgs.mkShell {
     buildInputs = with pkgs; [
       nodejs_20
       nodePackages.pnpm
       firefox
       chromium
     ];
     
     shellHook = ''
       export FIREFOX_PATH=$(which firefox)
       export CHROMIUM_PATH=$(which chromium)
     '';
   }
   ```

3. **Docker fallback for CI:**
   ```bash
   ./scripts/e2e-docker.sh
   ```

### 6.4 Caching Playwright Browsers

```yaml
# GitHub Actions caching
- name: Get Playwright version
  id: playwright-version
  run: |
    VERSION=$(pnpm ls @playwright/test --json | jq -r '.[0].devDependencies["@playwright/test"].version')
    echo "version=$VERSION" >> "$GITHUB_OUTPUT"

- name: Cache Playwright browsers
  uses: actions/cache@v4
  id: playwright-cache
  with:
    path: ~/.cache/ms-playwright
    key: playwright-${{ runner.os }}-${{ steps.playwright-version.outputs.version }}

- name: Install Playwright browsers
  if: steps.playwright-cache.outputs.cache-hit != 'true'
  run: npx playwright install --with-deps
```

**Note from Playwright docs:** Browser caching provides minimal benefit—download time is comparable to cache restoration time.

---

## 7. Proso Recommendations

### 7.1 Recommended Test Architecture

```
tests/
├── unit/                    # Jest unit tests
├── integration/             # Component integration tests
├── contract/                # API contract tests
├── e2e/
│   ├── extension/          # Chromium extension E2E (Playwright)
│   │   ├── fixtures/       # Extension fixture
│   │   ├── content-injection.spec.ts
│   │   ├── playback-flow.spec.ts
│   │   └── popup-ui.spec.ts
│   ├── content-injection.e2e.test.ts  # Firefox E2E (non-extension)
│   ├── playback-flow.e2e.test.ts
│   └── settings-page.e2e.test.ts
├── visual/                  # Firefox visual regression
│   ├── hover-preview.test.js
│   ├── sticky-footer.test.js
│   └── *.test.js-snapshots/
├── security/               # Security tests
└── helpers/               # Shared test utilities
```

### 7.2 Recommended Browser Strategy

| Test Type | Browser | Reason |
|-----------|---------|--------|
| Extension E2E | Chromium | Only browser with Playwright extension support |
| Visual regression | Firefox | Target browser for Proso |
| PDF testing | Chromium (extension) | Full extension context needed |
| Static validation | Firefox | Verify build artifacts |
| Settings page | Both | Browser-agnostic functionality |

### 7.3 Recommended Wait Strategies

```typescript
// Extension ready helper
export async function waitForExtensionReady(
  context: BrowserContext,
  timeout = 30000
): Promise<string> {
  const serviceWorker = await context.waitForEvent('serviceworker', { timeout });
  return serviceWorker.url().split('/')[2];
}

// Content script ready helper
export async function waitForContentScriptReady(
  page: Page,
  timeout = 5000
): Promise<boolean> {
  try {
    await page.waitForSelector('[data-proso-ready]', { timeout, state: 'attached' });
    return true;
  } catch {
    return false;
  }
}

// PDF ready helper
export async function waitForPdfReady(page: Page, timeout = 15000): Promise<void> {
  await page.waitForSelector('.pdfViewer', { timeout });
  await page.waitForSelector('.page canvas', { timeout });
  await page.waitForLoadState('networkidle');
}
```

### 7.4 Recommended Fixture Pattern

```typescript
// tests/e2e/extension/fixtures/extension.fixture.ts
import { test as base, chromium, type BrowserContext } from '@playwright/test';

export const test = base.extend<{
  context: BrowserContext;
  extensionId: string;
}>({
  context: async ({}, use) => {
    const extensionPath = getExtensionPath();
    
    const context = await chromium.launchPersistentContext('', {
      channel: 'chromium',
      headless: false,
      args: [
        `--disable-extensions-except=${extensionPath}`,
        `--load-extension=${extensionPath}`,
        '--headless=new', // Chrome 109+ headless with extension support
        '--disable-gpu',
        '--no-sandbox',
      ],
    });
    
    await use(context);
    await context.close();
  },
  
  extensionId: async ({ context }, use) => {
    const sw = context.serviceWorkers()[0] ?? 
               await context.waitForEvent('serviceworker', { timeout: 30000 });
    const extensionId = sw.url().split('/')[2];
    await use(extensionId);
  },
});
```

### 7.5 Recommended CI Configuration

Proso's current `test.yml` is well-structured. Recommendations for enhancement:

1. **Add Firefox-specific extension smoke test:**
   ```yaml
   firefox-smoke:
     name: Firefox Smoke Test
     runs-on: ubuntu-latest
     steps:
       - uses: actions/checkout@v4
       - run: pnpm install
       - run: pnpm build:firefox
       - name: Validate Firefox extension structure
         run: |
           test -f .output/firefox-mv2/manifest.json
           test -f .output/firefox-mv2/background.js
           test -f .output/firefox-mv2/content-scripts/content.js
   ```

2. **Add scheduled full browser matrix:**
   ```yaml
   nightly-full-matrix:
     if: github.event_name == 'schedule'
     strategy:
       matrix:
         browser: [chromium, firefox, webkit]
     steps:
       - run: npx playwright test --project=${{ matrix.browser }}
   ```

3. **Add visual snapshot update workflow:**
   ```yaml
   update-snapshots:
     if: github.event_name == 'workflow_dispatch'
     steps:
       - run: npx playwright test --update-snapshots
       - uses: peter-evans/create-pull-request@v5
         with:
           title: "Update visual snapshots"
           branch: update-snapshots
   ```

---

## References

### Official Documentation

- [Playwright Browsers Documentation](https://playwright.dev/docs/browsers)
- [Playwright Chrome Extensions](https://playwright.dev/docs/chrome-extensions)
- [Playwright Visual Comparisons](https://playwright.dev/docs/test-snapshots)
- [Playwright CI Configuration](https://playwright.dev/docs/ci)
- [Playwright Docker](https://playwright.dev/docs/docker)

### Firefox Extension Testing

- [Firefox Extension Workshop - Debugging](https://extensionworkshop.com/documentation/develop/debugging/)
- [Firefox Extension Workshop - Testing](https://extensionworkshop.com/documentation/develop/testing-persistent-and-restart-features/)
- [web-ext Command Reference](https://extensionworkshop.com/documentation/develop/web-ext-command-reference/)
- [MDN WebExtensions API](https://developer.mozilla.org/docs/Mozilla/Add-ons/WebExtensions)

### Proso Existing Documentation

- `docs/e2e-nixos.md` - NixOS E2E testing setup
- `tests/e2e/extension/fixtures/extension.fixture.ts` - Extension fixture implementation
- `playwright.config.js` - Current Playwright configuration
- `.github/workflows/test.yml` - CI workflow

---

## Summary

Proso's current testing strategy is well-designed given Playwright's limitations with Firefox extensions. Key takeaways:

1. **Chromium for extension E2E** - Playwright only supports extensions in Chromium
2. **Firefox for visual regression** - CSS-only tests work without extension loading
3. **Static validation for Firefox** - Verify manifest and file structure
4. **Docker for CI consistency** - Reproducible test environment
5. **web-ext for Firefox-specific testing** - Use Mozilla's official tool when full Firefox extension testing is needed

## Browser process hygiene (shared-host rule — 16/08/2026 incident)

**Incident:** a seat-level Brave E2E harness on Pedro's desktop ran `pkill -9 -x brave`
63× in an hour. `pkill -x brave` matches by process *name*, so it killed every Brave on
the host — including Pedro's real-profile desktop session — not just the harness's own
probe instance. Symptom on the victim side: "Brave closed ~30 s after launch; launcher
does nothing".

**Rule — killing is always scoped, never by bare process name:**

1. **Never** `pkill -9 -x brave`, `killall brave`, or `pkill -9 -f brave` from any
   harness, fixture, or seat prompt. A shared desktop host runs the owner's real
   browser; a name-match kill has no way to tell instances apart.
2. **Kill only what you spawned.** Capture the child PID at spawn and signal exactly
   that PID in `finally`. If you must sweep strays, match the probe's own unique
   marker — its `--user-data-dir=<...>` path or its temp root — and **verify with
   `pgrep -af` first**, then kill the listed PIDs, never a bare `-x <binary>`.
3. **Prefer isolation over cleanup.** When the host is a shared desktop, run browser
   probes inside a container (podman/docker) or under a dedicated user/seat so the
   cleanup surface is the container, not the process table.
4. If a probe genuinely cannot proceed without the port/profile free, scope the kill
   to the exact `--remote-debugging-port=<port>` AND the exact `--user-data-dir` you
   created, and confirm the match list before sending a signal.
5. Lint/self-review every harness for `pkill|killall` before running against a real
   display. A cleanup that needs root/pkill to "work" is a harness design bug.

**Why:** the owner's browser is the production surface on this host; a test harness's
cleanup bug must not be able to take it down. Scoped kills are strictly more precise
and cost nothing.
