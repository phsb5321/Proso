/**
 * API Client Port Interface
 *
 * Defines the contract for communication with the Proso backend server.
 * Used for license validation, subscription management, and managed TTS credits.
 *
 * @module ports/api-client
 */

import type {
  CheckoutResponse,
  CreditBalanceResponse,
  CreditHistoryResponse,
  ErrorCode,
  LicenseValidateResponse,
  SubscriptionDetailsResponse,
  TTSSynthesizeRequest,
  TTSTestKeyResponse,
} from '@proso/shared';
import type { Result } from '../core/shared/result';

/**
 * TTS synthesis response from the server.
 * Contains audio blob and metadata from response headers.
 */
export interface SynthesizeResponse {
  audioBlob: Blob;
  contentType: string;
  creditsUsed: number;
  creditsRemaining: number;
  cacheHit: boolean;
  provider: string;
}

/**
 * API client errors — discriminated union.
 */
export type ApiClientError =
  | { type: 'network'; message: string }
  | { type: 'timeout'; timeoutMs: number }
  | { type: 'unauthorized'; message: string; code?: ErrorCode }
  | {
      type: 'server_error';
      status: number;
      message: string;
      code?: ErrorCode;
      retryAfterMs?: number;
    }
  | { type: 'invalid_response'; message: string }
  | { type: 'not_configured'; message: string }
  | { type: 'aborted'; message: string };

/**
 * Port interface for Proso server communication.
 *
 * Adapters:
 * - ProsoApiAdapter (HTTP client with retry and auth)
 * - NoOpApiClientAdapter (returns free-tier defaults, used when server URL not configured)
 */
export interface IApiClient {
  /**
   * Adopt a license key (or clear it with null) for every subsequent call.
   *
   * The settings page's "Save & validate" is the production caller: the key it
   * accepts has to reach the live client, not only storage, or managed
   * synthesis keeps sending the key the container was born with until the next
   * browser start.
   *
   * @param key - Raw license key, or null to send no key at all
   */
  setLicenseKey(key: string | null): void;

  /**
   * Validate a license key against the server.
   * Returns the user's tier, features, and credit balance.
   *
   * INV-001: If the server is unreachable or no license key is configured,
   * callers should fall back to free tier defaults.
   *
   * @param licenseKey - Raw license key to validate
   */
  validateLicense(licenseKey: string): Promise<Result<LicenseValidateResponse, ApiClientError>>;

  /**
   * Get subscription details using an explicit candidate key when supplied,
   * otherwise the key currently adopted by the live client. Candidate
   * confirmation must not mutate the key concurrent synthesis uses.
   */
  getSubscription(
    licenseKey?: string,
  ): Promise<Result<SubscriptionDetailsResponse, ApiClientError>>;

  /**
   * Get the current credit balance for the authenticated user.
   */
  getCreditBalance(): Promise<Result<CreditBalanceResponse, ApiClientError>>;

  /**
   * Get credit transaction history for the authenticated user.
   *
   * @param limit - Max number of transactions to return (default 50)
   * @param offset - Number of transactions to skip (default 0)
   */
  getCreditHistory(
    limit?: number,
    offset?: number,
  ): Promise<Result<CreditHistoryResponse, ApiClientError>>;

  /**
   * Generate a checkout URL for upgrading to a paid tier.
   *
   * @param tier - Target subscription tier ('pro' or 'enterprise')
   */
  createCheckout(tier: string): Promise<Result<CheckoutResponse, ApiClientError>>;

  /**
   * Synthesize text to audio via the server TTS proxy.
   * Returns audio blob with metadata (credits used, cache hit, provider).
   *
   * When TTSSynthesizeRequest.byokApiKey is present, the server uses the
   * user's key for that single request without deducting managed credits.
   *
   * @param request - Text, provider, voice, language, and optional byokApiKey
   * @param signal - Optional caller-supplied AbortSignal, composed with the adapter's
   *   own per-call timeout. Aborting either aborts the underlying fetch.
   */
  synthesize(
    request: TTSSynthesizeRequest,
    signal?: AbortSignal,
  ): Promise<Result<SynthesizeResponse, ApiClientError>>;

  /**
   * Validate a BYOK API key via the server's test-key endpoint.
   *
   * @param provider - TTS provider to test against
   * @param apiKey - API key to validate
   */
  testApiKey(provider: string, apiKey: string): Promise<Result<TTSTestKeyResponse, ApiClientError>>;

  /**
   * Check if the API client is configured with a server URL.
   */
  readonly isConfigured: boolean;
}

/**
 * API client error helper factory.
 */
export const apiClientError = {
  network: (message: string): ApiClientError => ({
    type: 'network',
    message,
  }),
  timeout: (timeoutMs: number): ApiClientError => ({
    type: 'timeout',
    timeoutMs,
  }),
  unauthorized: (message: string, code?: ErrorCode): ApiClientError => ({
    type: 'unauthorized',
    message,
    code,
  }),
  serverError: (
    status: number,
    message: string,
    code?: ErrorCode,
    retryAfterMs?: number,
  ): ApiClientError => ({
    type: 'server_error',
    status,
    message,
    code,
    retryAfterMs,
  }),
  invalidResponse: (message: string): ApiClientError => ({
    type: 'invalid_response',
    message,
  }),
  notConfigured: (message: string): ApiClientError => ({
    type: 'not_configured',
    message,
  }),
  aborted: (message = 'Request was aborted'): ApiClientError => ({
    type: 'aborted',
    message,
  }),
};
