/**
 * Playback Message Handlers
 *
 * Handlers for playback-related messages in the hexagonal architecture.
 * These handlers delegate to the PlaybackService in the composition root.
 *
 * @module handlers/playback
 */

import { browser } from 'wxt/browser';
import { getPlaybackService, isPlaybackServiceAvailable } from '../composition';
import type { Result } from '../core/shared/result';
import { Err, Ok } from '../core/shared/result';
import type { HandlerRegistry } from './registry';

/**
 * Get the active tab in the current window.
 */
async function getActiveTab(): Promise<{ id?: number; url?: string } | null> {
  const tabs = await browser.tabs.query({ active: true, currentWindow: true });
  return tabs[0] || null;
}

/**
 * Send a message to a content script and get the response.
 */
async function sendToContentScript(
  tabId: number,
  message: Record<string, unknown>,
): Promise<unknown> {
  try {
    return await browser.tabs.sendMessage(tabId, message);
  } catch (error) {
    console.error('[PlaybackHandlers] Failed to send to content script:', error);
    return null;
  }
}

/**
 * Playback handler error type.
 */
export type PlaybackHandlerError =
  | { type: 'service_unavailable'; message: string }
  | { type: 'invalid_params'; message: string }
  | { type: 'operation_failed'; message: string };

/**
 * Response types for playback handlers.
 * Note: status values mapped from PlaybackState.status:
 * - 'idle' and 'error' are mapped to 'stopped' for compatibility with legacy handlers
 */
export interface PlaybackStateResponse {
  status: 'stopped' | 'loading' | 'playing' | 'paused';
  currentParagraph: number;
  totalParagraphs: number;
  progress: number;
  speed: number;
  provider: string;
  voice: string | null;
  currentTime: number;
  totalTime: number;
}

/**
 * Map PlaybackState.status to legacy status values.
 */
function mapStatusToLegacy(
  status: 'idle' | 'loading' | 'playing' | 'paused' | 'stopped' | 'error',
): 'stopped' | 'loading' | 'playing' | 'paused' {
  switch (status) {
    case 'idle':
    case 'error':
    case 'stopped':
      return 'stopped';
    case 'loading':
      return 'loading';
    case 'playing':
      return 'playing';
    case 'paused':
      return 'paused';
  }
}

/**
 * Extract error message from PlaybackError.
 * PlaybackError is a discriminated union - different variants have different properties.
 */
function getPlaybackErrorMessage(error: {
  type: string;
  message?: string;
  reason?: string;
  mode?: string;
  provider?: string;
  index?: number;
  max?: number;
  tabId?: number;
}): string {
  switch (error.type) {
    case 'audio_generation':
      return error.message ?? `Audio generation failed for provider ${error.provider}`;
    case 'no_content':
      return `No content found for mode: ${error.mode}`;
    case 'invalid_paragraph_index':
      return `Invalid paragraph index ${error.index} (max: ${error.max})`;
    case 'tab_not_found':
      return `Tab not found: ${error.tabId}`;
    case 'provider_unavailable':
      return `Provider unavailable: ${error.provider}`;
    case 'playback_failed':
      return error.reason ?? 'Playback failed';
    default:
      return `Unknown error: ${error.type}`;
  }
}

export interface PlaybackOperationResponse {
  success: boolean;
  error?: string;
  currentParagraph?: number;
}

/**
 * Register playback message handlers on the registry.
 *
 * Note: During the transition period, these handlers provide a facade
 * over the existing background.ts implementation. Once the full hexagonal
 * architecture is in place, they will delegate to PlaybackService.
 *
 * @param registry - Handler registry to register on
 */
export function registerPlaybackHandlers(registry: HandlerRegistry): void {
  /**
   * Get current playback state.
   */
  registry.register<void, Result<PlaybackStateResponse, PlaybackHandlerError>>(
    'playback.getState',
    async () => {
      if (!isPlaybackServiceAvailable()) {
        // During transition, return a stub response
        // This will be replaced with actual service call
        return Err({
          type: 'service_unavailable',
          message: 'PlaybackService not yet initialized. Use legacy handlers.',
        });
      }

      try {
        const service = getPlaybackService();
        const state = service.getState();

        // Calculate progress percentage for the overall article
        const overallProgress =
          state.totalParagraphs > 0
            ? (state.currentParagraphIndex / state.totalParagraphs) * 100
            : 0;

        // Note: currentTime and totalTime are approximations since PlaybackState
        // doesn't track audio duration. These will be 0 until audio is playing.
        return Ok({
          status: mapStatusToLegacy(state.status),
          currentParagraph: state.currentParagraphIndex,
          totalParagraphs: state.totalParagraphs,
          progress: overallProgress,
          speed: state.speed,
          provider: state.provider,
          voice: state.voice,
          currentTime: 0, // Audio timing tracked by audio element in PlaybackService
          totalTime: 0, // Audio timing tracked by audio element in PlaybackService
        });
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        return Err({ type: 'operation_failed', message });
      }
    },
    'Get current playback state',
  );

  /**
   * Start playback.
   *
   * This handler orchestrates playback start:
   * 1. Gets active tab if not provided
   * 2. Extracts text from content script if paragraphs not provided
   * 3. Shows footer UI
   * 4. Starts PlaybackService
   */
  registry.register<
    { paragraphs?: string[]; tabId?: number; pageUrl?: string },
    Result<PlaybackOperationResponse, PlaybackHandlerError>
  >(
    'playback.start',
    async (params) => {
      if (!isPlaybackServiceAvailable()) {
        return Err({
          type: 'service_unavailable',
          message: 'PlaybackService not yet initialized.',
        });
      }

      try {
        // Step 1: Get active tab if not provided
        let tabId = params.tabId;
        let pageUrl = params.pageUrl;

        if (!tabId || !pageUrl) {
          const tab = await getActiveTab();
          if (!tab?.id) {
            return Ok({ success: false, error: 'No active tab' });
          }
          tabId = tab.id;
          pageUrl = tab.url ?? '';
        }

        // Step 2: Extract paragraphs if not provided
        let paragraphs = params.paragraphs;

        if (!paragraphs || paragraphs.length === 0) {
          const extractResult = await sendToContentScript(tabId, {
            action: 'extractText',
            mode: 'article',
          });

          if (
            extractResult &&
            typeof extractResult === 'object' &&
            'paragraphs' in extractResult
          ) {
            const result = extractResult as { paragraphs: string[] };
            paragraphs = result.paragraphs;
          } else {
            return Ok({ success: false, error: 'Failed to extract text' });
          }
        }

        if (paragraphs.length === 0) {
          return Ok({ success: false, error: 'No text found on page' });
        }

        // Step 3: Show footer UI
        const service = getPlaybackService();
        const state = service.getState();

        await sendToContentScript(tabId, {
          action: 'FOOTER_SHOW',
          initialState: {
            isPlaying: true,
            currentIndex: 0,
            totalParagraphs: paragraphs.length,
            progress: 0,
            speed: state.speed,
          },
        });

        // Step 4: Start PlaybackService
        const result = await service.start(paragraphs, tabId, pageUrl);

        if (!result.ok) {
          return Ok({ success: false, error: getPlaybackErrorMessage(result.error) });
        }

        return Ok({ success: true });
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        return Err({ type: 'operation_failed', message });
      }
    },
    'Start playback',
  );

  /**
   * Pause playback.
   */
  registry.register<void, Result<PlaybackOperationResponse, PlaybackHandlerError>>(
    'playback.pause',
    async () => {
      if (!isPlaybackServiceAvailable()) {
        return Err({
          type: 'service_unavailable',
          message: 'PlaybackService not yet initialized. Use legacy handlers.',
        });
      }

      try {
        const service = getPlaybackService();
        service.pause();
        return Ok({ success: true });
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        return Err({ type: 'operation_failed', message });
      }
    },
    'Pause playback',
  );

  /**
   * Resume playback.
   */
  registry.register<void, Result<PlaybackOperationResponse, PlaybackHandlerError>>(
    'playback.resume',
    async () => {
      if (!isPlaybackServiceAvailable()) {
        return Err({
          type: 'service_unavailable',
          message: 'PlaybackService not yet initialized. Use legacy handlers.',
        });
      }

      try {
        const service = getPlaybackService();
        const result = await service.resume();

        if (!result.ok) {
          return Ok({ success: false, error: getPlaybackErrorMessage(result.error) });
        }

        return Ok({ success: true });
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        return Err({ type: 'operation_failed', message });
      }
    },
    'Resume playback',
  );

  /**
   * Stop playback.
   */
  registry.register<void, Result<PlaybackOperationResponse, PlaybackHandlerError>>(
    'playback.stop',
    async () => {
      if (!isPlaybackServiceAvailable()) {
        return Err({
          type: 'service_unavailable',
          message: 'PlaybackService not yet initialized. Use legacy handlers.',
        });
      }

      try {
        const service = getPlaybackService();
        service.stop();
        return Ok({ success: true });
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        return Err({ type: 'operation_failed', message });
      }
    },
    'Stop playback',
  );

  /**
   * Skip to next paragraph.
   */
  registry.register<void, Result<PlaybackOperationResponse, PlaybackHandlerError>>(
    'playback.next',
    async () => {
      if (!isPlaybackServiceAvailable()) {
        return Err({
          type: 'service_unavailable',
          message: 'PlaybackService not yet initialized. Use legacy handlers.',
        });
      }

      try {
        const service = getPlaybackService();
        const result = await service.next();

        if (!result.ok) {
          return Ok({ success: false, error: getPlaybackErrorMessage(result.error) });
        }

        const state = service.getState();
        return Ok({ success: true, currentParagraph: state.currentParagraphIndex });
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        return Err({ type: 'operation_failed', message });
      }
    },
    'Skip to next paragraph',
  );

  /**
   * Skip to previous paragraph.
   */
  registry.register<void, Result<PlaybackOperationResponse, PlaybackHandlerError>>(
    'playback.previous',
    async () => {
      if (!isPlaybackServiceAvailable()) {
        return Err({
          type: 'service_unavailable',
          message: 'PlaybackService not yet initialized. Use legacy handlers.',
        });
      }

      try {
        const service = getPlaybackService();
        const result = await service.previous();

        if (!result.ok) {
          return Ok({ success: false, error: getPlaybackErrorMessage(result.error) });
        }

        const state = service.getState();
        return Ok({ success: true, currentParagraph: state.currentParagraphIndex });
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        return Err({ type: 'operation_failed', message });
      }
    },
    'Skip to previous paragraph',
  );

  /**
   * Seek to specific paragraph.
   */
  registry.register<
    { paragraphIndex: number },
    Result<PlaybackOperationResponse, PlaybackHandlerError>
  >(
    'playback.seekToParagraph',
    async (params) => {
      if (!isPlaybackServiceAvailable()) {
        return Err({
          type: 'service_unavailable',
          message: 'PlaybackService not yet initialized. Use legacy handlers.',
        });
      }

      if (typeof params.paragraphIndex !== 'number') {
        return Err({
          type: 'invalid_params',
          message: 'paragraphIndex must be a number',
        });
      }

      try {
        const service = getPlaybackService();
        const result = await service.seekToParagraph(params.paragraphIndex);

        if (!result.ok) {
          return Ok({ success: false, error: getPlaybackErrorMessage(result.error) });
        }

        return Ok({ success: true, currentParagraph: params.paragraphIndex });
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        return Err({ type: 'operation_failed', message });
      }
    },
    'Seek to specific paragraph',
  );

  /**
   * Set playback speed.
   */
  registry.register<{ speed: number }, Result<PlaybackOperationResponse, PlaybackHandlerError>>(
    'playback.setSpeed',
    async (params) => {
      if (!isPlaybackServiceAvailable()) {
        return Err({
          type: 'service_unavailable',
          message: 'PlaybackService not yet initialized. Use legacy handlers.',
        });
      }

      if (typeof params.speed !== 'number' || params.speed < 0.5 || params.speed > 2.0) {
        return Err({
          type: 'invalid_params',
          message: 'speed must be a number between 0.5 and 2.0',
        });
      }

      try {
        const service = getPlaybackService();
        service.setSpeed(params.speed);
        return Ok({ success: true });
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        return Err({ type: 'operation_failed', message });
      }
    },
    'Set playback speed',
  );

  /**
   * Seek to position by progress percentage.
   * T023: Added for compatibility with legacy seekToPosition handler.
   * Converts progress (0-100) to paragraph index.
   */
  registry.register<{ progress: number }, Result<PlaybackOperationResponse, PlaybackHandlerError>>(
    'playback.seek',
    async (params) => {
      if (!isPlaybackServiceAvailable()) {
        return Err({
          type: 'service_unavailable',
          message: 'PlaybackService not yet initialized. Use legacy handlers.',
        });
      }

      if (typeof params.progress !== 'number' || params.progress < 0 || params.progress > 100) {
        return Err({
          type: 'invalid_params',
          message: 'progress must be a number between 0 and 100',
        });
      }

      try {
        const service = getPlaybackService();
        const state = service.getState();

        // Convert progress percentage to paragraph index
        const paragraphIndex =
          state.totalParagraphs > 0
            ? Math.floor((params.progress / 100) * state.totalParagraphs)
            : 0;

        const result = await service.seekToParagraph(paragraphIndex);

        if (!result.ok) {
          return Ok({ success: false, error: getPlaybackErrorMessage(result.error) });
        }

        return Ok({ success: true, currentParagraph: paragraphIndex });
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        return Err({ type: 'operation_failed', message });
      }
    },
    'Seek to position by progress percentage',
  );
}
