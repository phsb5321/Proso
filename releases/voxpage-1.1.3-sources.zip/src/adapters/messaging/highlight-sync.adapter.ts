/**
 * Highlight Synchronizer Adapter
 *
 * Adapter implementing IHighlightSynchronizer port using browser.tabs.sendMessage.
 * Sends highlight and footer commands to content scripts.
 *
 * @module adapters/messaging/highlight-sync
 */

import type { HighlightError } from '../../core/shared/errors';
import { highlightError } from '../../core/shared/errors';
import type { Result } from '../../core/shared/result';
import { Err, Ok } from '../../core/shared/result';
import type { FooterState, IHighlightSynchronizer } from '../../ports/highlight-sync.port';

/**
 * Highlight synchronizer adapter using browser tabs messaging.
 *
 * Sends messages to content scripts for:
 * - Paragraph highlighting
 * - Word highlighting
 * - Footer visibility control
 * - Footer state updates
 */
export class HighlightSyncAdapter implements IHighlightSynchronizer {
  /**
   * Send message to content script.
   * @param tabId - Tab to send message to
   * @param message - Message payload
   */
  private async sendToContentScript(
    tabId: number,
    message: Record<string, unknown>,
  ): Promise<unknown> {
    try {
      return await browser.tabs.sendMessage(tabId, message);
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : String(error);
      throw new Error(`Failed to send message to tab ${tabId}: ${errorMsg}`);
    }
  }

  async highlightParagraph(
    tabId: number,
    paragraphIndex: number,
    scroll: boolean,
  ): Promise<Result<void, HighlightError>> {
    try {
      await this.sendToContentScript(tabId, {
        type: 'highlight.paragraph',
        paragraphIndex,
        scroll,
      });
      return Ok(undefined);
    } catch (error) {
      return Err(this.toHighlightError(tabId, error));
    }
  }

  async highlightWord(
    tabId: number,
    paragraphIndex: number,
    wordIndex: number,
  ): Promise<Result<void, HighlightError>> {
    try {
      await this.sendToContentScript(tabId, {
        type: 'highlight.word',
        paragraphIndex,
        wordIndex,
      });
      return Ok(undefined);
    } catch (error) {
      return Err(this.toHighlightError(tabId, error));
    }
  }

  async clearHighlights(tabId: number): Promise<Result<void, HighlightError>> {
    try {
      await this.sendToContentScript(tabId, {
        type: 'highlight.clear',
      });
      return Ok(undefined);
    } catch (error) {
      return Err(this.toHighlightError(tabId, error));
    }
  }

  async showFooter(tabId: number): Promise<Result<void, HighlightError>> {
    try {
      await this.sendToContentScript(tabId, {
        type: 'footer.show',
      });
      return Ok(undefined);
    } catch (error) {
      return Err(this.toHighlightError(tabId, error));
    }
  }

  async hideFooter(tabId: number): Promise<Result<void, HighlightError>> {
    try {
      await this.sendToContentScript(tabId, {
        type: 'footer.hide',
      });
      return Ok(undefined);
    } catch (error) {
      return Err(this.toHighlightError(tabId, error));
    }
  }

  async updateFooterState(
    tabId: number,
    state: FooterState,
  ): Promise<Result<void, HighlightError>> {
    try {
      await this.sendToContentScript(tabId, {
        type: 'footer.updateState',
        status: state.status,
        currentIndex: state.currentIndex,
        totalParagraphs: state.totalParagraphs,
        progress: state.progress,
        currentText: state.currentText,
        speed: state.speed,
      });
      return Ok(undefined);
    } catch (error) {
      return Err(this.toHighlightError(tabId, error));
    }
  }

  /**
   * Convert error to appropriate HighlightError type.
   */
  private toHighlightError(tabId: number, error: unknown): HighlightError {
    const message = error instanceof Error ? error.message : String(error);

    // Check for common browser API errors
    if (
      message.includes('No tab') ||
      message.includes('Invalid tab') ||
      message.includes('tab was closed')
    ) {
      return highlightError.tabNotFound(tabId);
    }

    if (
      message.includes('receiving end does not exist') ||
      message.includes('Could not establish connection')
    ) {
      return highlightError.contentScriptNotLoaded();
    }

    return highlightError.messageFailed(message);
  }
}
